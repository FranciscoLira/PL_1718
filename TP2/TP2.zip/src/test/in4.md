#H1
##H2
###H3
####H4
#####H5
######H6

Emphasis, aka italics, with *asterisks* or _underscores_.

Strong emphasis, aka bold, with **asterisks** or __underscores__.

Combined emphasis with **asterisks and _underscores_**.

Strikethrough uses two tildes. ~~Scratch this.~~

1. First ordered list item
2. Another item
0. Unordered sub-list. 
0. Actual numbers don't matter, just that it's a number
3. Ordered sub-list
4. And another item.


[I'm an inline-style link](https://www.google.com)
[I'm an another inline-style link with title](www.twitter.com)

```
ISTO é codigo
```